#include "BanderaDeOleada.h"

void BanderaDeOleada::mostrar() {
	//codigo
}

void BanderaDeOleada::alerta() {
	//codigo
}

void BanderaDeOleada::moverBarra() {
	//codigo
}

void BanderaDeOleada::cambiarNumOleada() {
	//codigo
}

void BanderaDeOleada::reiniciar() {
	//codigo
}