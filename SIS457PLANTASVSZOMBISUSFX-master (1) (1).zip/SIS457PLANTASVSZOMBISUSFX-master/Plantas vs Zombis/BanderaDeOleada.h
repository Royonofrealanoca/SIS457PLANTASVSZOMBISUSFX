#pragma once

class BanderaDeOleada
{
	//propiedades o atributos
	char forma;
	int  numBandera;
	char color;
	char logotipo;
	float posicion;

	//metodos o funciones
	void mostrar();
	void alerta();
	void moverBarra();
	void cambiarNumOleada();
	void reiniciar();
};

