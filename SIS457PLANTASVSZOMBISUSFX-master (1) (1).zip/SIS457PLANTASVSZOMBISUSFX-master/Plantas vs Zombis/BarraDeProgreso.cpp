#include "BarraDeProgreso.h"
BarraDeProgreso::BarraDeProgreso()
{
	posicion = 2;
	tamanio = 3;
	tiempo = 1;
	color = "plomo";
}

void BarraDeProgreso::iniciar() {
	//codigo
	cout << "la barra de progreso se esta iniciando"<<endl;
}

void BarraDeProgreso::velocidad() {
	//codigo
}

void BarraDeProgreso::finalizar() {
	//codigo
}

void BarraDeProgreso::gestionarProgreso() {
	//codigo
}