#pragma once
#include "BarraDeProgreso.h"
class BarraDeProgresoFuego :
    public BarraDeProgreso
{
};

