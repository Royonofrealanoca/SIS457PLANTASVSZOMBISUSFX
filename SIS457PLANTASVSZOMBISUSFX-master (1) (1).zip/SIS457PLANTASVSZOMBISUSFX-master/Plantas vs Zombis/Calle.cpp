#include "Calle.h"

void Calle::dibujarCalle() {
	//codigo
}

void Calle::contenedor() {
	//codigo
}

void Calle::agregarZombi() {
	//codigo
}