#include "Casa.h"

void Casa::visualizarEscenario() {
	//codigo
}

void Casa::AmenazaALaPuerta() {
	//codigo
}

void Casa::finalizarJuego() {
	//codigo
}