#include "Casilla.h"

void Casilla::comprobarEstado() {
	//codigo
}

void Casilla::a�adirPlanta() {
	//codigo
}

void Casilla::ocuparEspacio() {
	//codigo
}

void Casilla::desocuparEspacio() {
	//codigo
}

void Casilla::actualizarEstado() {
	//codigo
}