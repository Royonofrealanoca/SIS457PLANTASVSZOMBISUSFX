#include "Cerca.h"

void Cerca::visualizar() {
	//codigo
}

void Cerca::posicionarCerca() {
	//codigo
}