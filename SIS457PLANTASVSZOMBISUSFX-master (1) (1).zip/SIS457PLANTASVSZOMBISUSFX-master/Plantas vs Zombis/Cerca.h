#pragma once

class Cerca
{
	//propiedades o atributos
	float posicion;  //coordenadas de su ubicacion
	char apariencia;
	char color;
	int tamanio;

	//metodos o funciones
	void visualizar();
	void posicionarCerca();
};

