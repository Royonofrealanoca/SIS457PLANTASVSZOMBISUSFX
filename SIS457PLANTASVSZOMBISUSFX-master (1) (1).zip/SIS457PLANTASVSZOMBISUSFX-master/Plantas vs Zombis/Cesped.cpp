#include "Cesped.h"

void Cesped::recibirPlantaciones() {
	//codigo
}

void Cesped::extensionesANivel() {
	//codigo
}