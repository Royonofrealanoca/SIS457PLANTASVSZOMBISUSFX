#pragma once

class Cesped
{
	//propiedades 
	char forma; //rectangulo
	char color; //verde 
	char tama�o;
	int fila;
	int columna;

	//metodos o funciones

	void recibirPlantaciones();
	void extensionesANivel();
};

