#include "ContadorDeMoneda.h"

void ContadorDeMoneda::contar() {
	//codigo
}

void ContadorDeMoneda::incrementar() {
	//codigo
}

void ContadorDeMoneda::decrementar() {
	//codigo
}

int ContadorDeMoneda::mostrarTotalMonedas() {    //la funcion va a regresar un valor entero
	//codigo
	return 0;
}

void ContadorDeMoneda::aparecer() {
	//codigo
}

void ContadorDeMoneda::desaparecer() {
	//codigo
}