#include "ContadorDeSol.h"

void ContadorDeSol::acumularSoles() {
	//codigo
}

void ContadorDeSol::incrementar() {
	//codigo
}

void ContadorDeSol::decrementar() {
	//codigo
}

void ContadorDeSol::mostrarTotalSoles() {
	//codigo
}

void ContadorDeSol::gestionarSoles() {
	//codigo
}

void ContadorDeSol::gastarSoles() {
	//codigo
}

void ContadorDeSol::actualizarVisualizacion() {
	//codigo
}