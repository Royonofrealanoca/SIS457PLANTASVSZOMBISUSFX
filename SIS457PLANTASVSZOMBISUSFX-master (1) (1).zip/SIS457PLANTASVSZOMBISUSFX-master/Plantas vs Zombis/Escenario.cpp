#include "Escenario.h"

void Escenario::inicializar() {
	//codigo
}

void Escenario::visualizarNitidezFondo() {
	//codigo
}

void Escenario::agregarElemento() {
	//codigo
}

void Escenario::eliminarElemento() {
	//codigo
}

void Escenario::gestionarEventos() {
	//codigo
}

void Escenario::vericarCondicionesDeVictoria_Derrota() {
	//codigo
}

void Escenario::controlarTiempo() {
	//codigo
}

void Escenario::interaccionGlobalDeObjetos() {
	//codigo
}

void Escenario::guardarEstadoJuego() {
	//codigo
}