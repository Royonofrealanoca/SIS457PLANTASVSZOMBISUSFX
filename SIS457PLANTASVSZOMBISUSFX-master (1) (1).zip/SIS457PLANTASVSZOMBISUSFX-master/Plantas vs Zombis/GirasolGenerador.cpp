#include "GirasolGenerador.h"


//funciones propias
void GirasolGenerador::darSol() {
	intervaloGenerar = 5;

	for (int i = 1; i < 10; i++) {
		//posicionX = cantidad / intervaloGenerar;
		//posicionY = ............;
	}
}