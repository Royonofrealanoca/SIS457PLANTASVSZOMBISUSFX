#include "JuegoPersonalizado.h"

//JuegoPersonalizado::JuegoPersonalizado() {
//	colorFondo = "rosa";
//	sonido = "musica relajante";				//...las clases hijas no tienen constructores...?
//}


//----------funcion de esta clase hija

void JuegoPersonalizado::colocarSonido() {

}