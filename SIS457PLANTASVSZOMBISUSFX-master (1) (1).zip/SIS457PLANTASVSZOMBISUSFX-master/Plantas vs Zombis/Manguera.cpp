#include "Manguera.h"

void Manguera::visualizar() {
	//codigo
}

void Manguera::nitidezDeImagen() {
	//codigo
}

void Manguera::decoracion() {
	//codigo
}