#pragma once

class Manguera
{
	//propiedades o atributos

	char estado;  //quieto
	char forma;
	char color;
	int tamanio;
	int posicion;

	//metodos o funciones

	void visualizar();
	void nitidezDeImagen();
	void decoracion();
};

