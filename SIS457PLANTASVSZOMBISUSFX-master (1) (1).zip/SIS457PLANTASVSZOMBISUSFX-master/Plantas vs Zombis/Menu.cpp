#include "Menu.h"
Menu::Menu()
{
	numeroOpcion = 3;
    estado = 100;
	seleccionarOpcion = 2;
	fondo = 1;
}

void Menu::moverBarra() {
	//codigo
}

void Menu::activarOpcion() {
	//codigo
}

void Menu::mostrarOpcion() {
	//codigo
}

void Menu::ocultarMenu() {
	//codigo
}

void Menu::actualizarMenu() {
	//codigo
}

void Menu::cargarPantallas() {
	//codigo
}

void Menu::personalizacion() {
	//codigo
}

void Menu::salirDelJuego() {
	//codigo
}