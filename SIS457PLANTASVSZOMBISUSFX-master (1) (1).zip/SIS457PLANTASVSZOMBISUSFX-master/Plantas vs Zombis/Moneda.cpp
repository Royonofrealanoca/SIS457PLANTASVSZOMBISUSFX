#include "Moneda.h"

void Moneda::comprar() {
	//codigo
}

void Moneda::visualizarMoneda() {
	//codigo
}

void Moneda::establecerPosiciones() {
	//codigo
}

void Moneda::gestionarAnimacion() {
	//codigo
}