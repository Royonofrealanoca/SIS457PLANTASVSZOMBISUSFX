#include "Pala.h"

void Pala::tipoAccion() {
	//codigo
}

void Pala::quitarPlanta() {
	//codigo
}