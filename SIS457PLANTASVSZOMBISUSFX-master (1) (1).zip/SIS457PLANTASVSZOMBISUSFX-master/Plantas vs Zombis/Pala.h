#pragma once
#include <iostream>

using namespace std;

class Pala
{
	//propiedades o atributos
	string color;
	int tamanio;
	int posicion;

	//metodos o funciones
	void tipoAccion();     //mover planta o quitar
	void quitarPlanta();
};

