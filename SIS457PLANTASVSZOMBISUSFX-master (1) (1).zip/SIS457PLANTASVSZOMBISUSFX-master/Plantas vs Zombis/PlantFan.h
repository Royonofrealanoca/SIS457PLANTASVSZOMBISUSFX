#pragma once
#include "Planta.h"
class PlantFan : public Planta
{
public:
	//constructor
	PlantFan();

	//metodo propio
	void Defender();
};

