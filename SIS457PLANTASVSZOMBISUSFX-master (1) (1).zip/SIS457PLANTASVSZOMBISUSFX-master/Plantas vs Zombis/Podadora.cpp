#include "Podadora.h"

void Podadora::activacion() {
	//codigo
}

void Podadora::eliminarAmenaza() {
	//codigo
}