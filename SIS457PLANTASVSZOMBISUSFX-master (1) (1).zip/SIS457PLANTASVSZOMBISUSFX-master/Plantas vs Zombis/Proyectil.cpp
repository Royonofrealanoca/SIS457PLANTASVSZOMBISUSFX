#include "Proyectil.h"
Proyectil::Proyectil()
{
	tama�o = 1;
	tipoProyectil = 3;
	color = 'M';
}

void Proyectil::visualizarProyectil() {
	//codigo
	cout<<"El proyectil a sido disparado ";
}

void Proyectil::velocidad() {
	//codigo
}