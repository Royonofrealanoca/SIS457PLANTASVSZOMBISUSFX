#include "Rastrillo.h"

void Rastrillo::atacar() {
	//codigo
}

void Rastrillo::configurarDurabilidad() {
	//codigo
}

void Rastrillo::comprar() {
	//codigo
}