#include "Sol.h"

void Sol::gestionarAparicion() {
	//codigo
}

void Sol::visualizacion() {
	//codigo
}

void  Sol::comprarplantas() {
	//codigo
}