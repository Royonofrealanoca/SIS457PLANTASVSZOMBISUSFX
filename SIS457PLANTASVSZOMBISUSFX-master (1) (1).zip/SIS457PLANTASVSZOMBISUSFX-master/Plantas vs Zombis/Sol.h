#pragma once

class Sol
{
	//propiedades o atributos

	char color; //amarillo
	int valor;
	char tamanio;
	char forma;
	char posicion;

	//metodos o funciones
	void gestionarAparicion();
	void visualizacion();
	void  comprarplantas();
};

