#include "SpawnerDeMoneda.h"

void SpawnerDeMoneda::generarMoneda() {
	//codigo
}

void SpawnerDeMoneda::configurarTipoMoneda() {
	//codigo
}

void SpawnerDeMoneda::actualizar() {
	//codigo
}

void SpawnerDeMoneda::configurarPosicion() {
	//codigo
}

void SpawnerDeMoneda::configurarFrecuencia() {
	//codigo
}

void SpawnerDeMoneda::configurarCantidad() {
	//codigo
}