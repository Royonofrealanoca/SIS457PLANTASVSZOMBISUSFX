#include "SpawnerDeZombi.h"

void SpawnerDeZombi::iniciarOleada() {
	//codigo
}

void SpawnerDeZombi::configurarTipoZombi() {
	//codigo
}

void SpawnerDeZombi::generarZombi() {
	//codigo
}

void SpawnerDeZombi::actualizar() {
	//codigo
}

void SpawnerDeZombi::configurarPosicion() {
	//codigo
}

void SpawnerDeZombi::configurarFrecuencia() {
	//codigo
}

void SpawnerDeZombi::configurarCantidad() {
	//codigo
}