#include "Temporizador.h"

void Temporizador::comprobarActivacion() {
	//codigo
}

void Temporizador::iniciar() {
	//codigo
}

void Temporizador::finalizar() {
	//codigo
}

void Temporizador::reiniciar() {
	//codigo
}

void Temporizador::establecerDuracion() {
	//codigo
}