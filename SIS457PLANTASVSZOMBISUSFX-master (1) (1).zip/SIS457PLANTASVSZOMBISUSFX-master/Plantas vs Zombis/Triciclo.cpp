#include "Triciclo.h"

void Triciclo::visualizar() {
	//codigo
}

void Triciclo::nitidezDeImagen() {
	//codigo
}

void Triciclo::decoracion() {
	//codigo
}