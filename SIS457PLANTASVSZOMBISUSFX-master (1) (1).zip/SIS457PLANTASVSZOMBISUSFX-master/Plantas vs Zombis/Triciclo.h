#pragma once

class Triciclo
{
	//propiedades o atributos

	char estado;
	char forma; //triciclo
	char color; //rosa,rojo 
	int tamanio;
	int posicion;

	//metodos o funciones

	void visualizar();
	void nitidezDeImagen();
	void decoracion();
};

