#pragma once
#include "Planta.h"
class UmbrellaPlant : public Planta
{
public:
	//constructor
	UmbrellaPlant();

	//metodo propio
	void soplar();
};

