#pragma once
#include "Zombi.h"
class ZombiAtleta : public Zombi
{
public:
	//constructor
	ZombiAtleta();

	//metodo propio
	void Correr();
	void Saltar();
};

