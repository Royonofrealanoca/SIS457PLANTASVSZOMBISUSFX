#pragma once
#include "Zombi.h"
class ZombiCarpintero : public Zombi
{
public:
	/*constructor*/
	ZombiCarpintero();

	//metodo propio
	void escalar();
};

