#pragma once
#include "Zombi.h"
class ZombiLadron : public Zombi
{
public:
	//constructor
	ZombiLadron();

	//Metodos propios
	void Robar();
};

