#pragma once
#include "Zombi.h"
class ZombiSaltarin : public Zombi
{
public:
	//constructor
	ZombiSaltarin();

	//metodo propio
	void saltar();
};

