#pragma once
#include "peashooter.h"
class peashooterIce :public peashooter
{
	/*metodo propio*/
	void EfectIce();
};

