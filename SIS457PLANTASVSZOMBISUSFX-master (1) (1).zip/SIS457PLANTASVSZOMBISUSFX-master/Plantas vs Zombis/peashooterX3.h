#pragma once
#include "peashooter.h"
#include "Proyectil.h"
class peashooterX3 :public peashooter
{
	//metodo propio 
	void disparar3Lineas();
};

