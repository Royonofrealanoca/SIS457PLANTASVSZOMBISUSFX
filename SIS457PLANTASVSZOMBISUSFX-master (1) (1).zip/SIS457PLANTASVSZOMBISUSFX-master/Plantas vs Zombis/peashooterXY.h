#pragma once
#include "peashooter.h"
class peashooterXY :public peashooter
{
	//metodo propio
	void dispararXY();
};

